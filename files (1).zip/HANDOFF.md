# HANDOFF: Electro Shop (الکتروهاب)

Persian (RTL) electronic component store. Built with TanStack Start, deployed to Cloudflare Workers (free tier) through GitHub Actions. This file is everything you need to develop and deploy it yourself, with no AI agent.

**Status:** Front-end prototype only. It was generated but never run or built, so expect to fix small version issues on the first install. There is no database, no checkout and no payment gateway yet. Products in `src/data.ts` are sample data.

---

## 1. Stack

| Part | Tool |
|---|---|
| Framework | TanStack Start (React 19, file-based routing, SSR) |
| Build | Vite 7 + `@cloudflare/vite-plugin` |
| Hosting | Cloudflare Workers (free tier) |
| CI/CD | GitHub Actions + `cloudflare/wrangler-action` |
| Styling | Plain CSS (`src/styles.css`), CSS animations only |

## 2. Structure

```
electro-shop/
  .github/workflows/deploy.yml   # deploys on every push to main
  src/
    routes/__root.tsx            # HTML shell: lang="fa" dir="rtl", head, meta
    routes/index.tsx             # home page: hero, filters, product grid, cart state
    router.tsx                   # router factory (getRouter)
    data.ts                      # sample products and categories
    styles.css                   # theme variables + all animations
    routeTree.gen.ts             # AUTO-GENERATED on dev/build, gitignored, do not edit
  vite.config.ts                 # cloudflare() + tanstackStart() + react()
  wrangler.jsonc                 # Worker name, compat date, entry
  package.json
```

New page = new file in `src/routes/`. Example: `src/routes/product.$id.tsx` becomes `/product/123`.

## 3. Run locally

Requirements: Node 22+, npm.

```bash
npm install
npm run dev        # http://localhost:3000 (Vite prints the exact port)
```

Right after the first successful `npm install`, commit `package-lock.json`. Dependencies are set to `latest` for TanStack and Cloudflare packages, so the lockfile is what keeps builds repeatable.

## 4. Deploy

### Option A: automatic (recommended)

1. Create a GitHub repo and push this project to the `main` branch.
2. Cloudflare dashboard > My Profile > API Tokens > Create Token > template **Edit Cloudflare Workers**.
3. Copy your **Account ID** (Workers & Pages overview page, right side).
4. GitHub repo > Settings > Secrets and variables > Actions > add:
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ACCOUNT_ID`
5. Push to `main`. The Actions tab shows the run. The site goes live at `https://electro-shop.<your-subdomain>.workers.dev`.

### Option B: manual from your machine

```bash
npx wrangler login
npm run build
npx wrangler deploy
```

### Custom domain

Add the domain to Cloudflare (change its nameservers to the ones Cloudflare gives you), then Workers & Pages > your Worker > Settings > Domains & Routes > Add custom domain. Cloudflare does not register `.ir` domains; buy it elsewhere and only point the nameservers.

## 5. Common problems

| Symptom | Fix |
|---|---|
| `routeTree.gen` not found | Run `npm run dev` or `npm run build` once; the plugin generates it. |
| Build fails right after install with an API or import error | A `latest` package moved. Check the TanStack Start docs (Cloudflare hosting page) and compare `vite.config.ts`, `src/router.tsx` and `__root.tsx`. Pin working versions in `package.json`. |
| Action fails with an auth error | Re-check both secrets and that the token has Workers edit permission. |
| Action fails on `npm ci` | The workflow uses `npm install`; if you switch to `npm ci`, the lockfile must be committed. |
| Persian text in the wrong font | Fonts are not loaded from Google (often blocked in Iran). Put Vazirmatn `.woff2` files in `public/` and add `@font-face` in `styles.css`. |
| Site slow or unreachable from some Iranian ISPs | Test from several networks. Cloudflare reachability varies by ISP; consider this before launch. |

## 6. Free tier limits

Workers free plan limits daily requests and CPU time per request. Check the current numbers on Cloudflare's Workers pricing page before launch. D1 (database) and R2 (images) also have free tiers.

## 7. Suggested roadmap

1. **Real products:** Cloudflare D1 (SQLite). Create with `npx wrangler d1 create electro-db`, bind it in `wrangler.jsonc`, load it in route `loader`s with a TanStack Start server function.
2. **Product pages:** `src/routes/product.$id.tsx` with `loader`, plus SEO titles and descriptions per page.
3. **Cart persistence:** move cart state out of `index.tsx` into a small store saved in `localStorage` (guard for SSR).
4. **Images:** upload to Cloudflare R2 and serve through a Worker route or a public bucket domain.
5. **Checkout:** Iranian gateway (for example Zarinpal): create a payment request in a server function, redirect the user, verify in a callback route. Keep the merchant ID in Worker secrets (`npx wrangler secret put NAME`), never in the repo.
6. **Admin panel:** protected route to add and edit products and see orders.
7. **Polish:** sitemap, `robots.txt`, favicon, Persian number formatting everywhere (`toLocaleString('fa-IR')` is already used), accessibility pass.

## 8. Conventions

- All user-facing text is Persian; code and comments are English.
- Prices are in Toman, stored as integers.
- Theme colors live in `:root` variables at the top of `styles.css`.
- Animations respect `prefers-reduced-motion`; keep that rule when adding new ones.
- Never commit secrets. Use GitHub Actions secrets and `wrangler secret`.

## 9. Useful links

- TanStack Start docs: tanstack.com/start (see "Hosting" > Cloudflare)
- Cloudflare Workers docs: developers.cloudflare.com/workers
- Wrangler config reference: developers.cloudflare.com/workers/wrangler/configuration
